package br.com.alurafood.avaliacao.avaliacao.dto;

public enum StatusPagamento {
    CRIADO,
    CONFIRMADO,
    CONFIRMADO_SEM_INTEGRACAO,
    CANCELADO
}
