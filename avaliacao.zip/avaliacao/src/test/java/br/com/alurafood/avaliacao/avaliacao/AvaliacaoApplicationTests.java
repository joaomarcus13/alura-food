package br.com.alurafood.avaliacao.avaliacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvaliacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
